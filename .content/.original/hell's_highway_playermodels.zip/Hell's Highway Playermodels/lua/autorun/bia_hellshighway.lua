if (SERVER) then
	player_manager.AddValidModel( "bia1", "models/jessev92/player/biahh/bia1.mdl" )
	player_manager.AddValidModel( "bia2", "models/jessev92/player/biahh/bia2.mdl" )
	player_manager.AddValidModel( "bia3", "models/jessev92/player/biahh/bia3.mdl" )
	player_manager.AddValidModel( "bia4", "models/jessev92/player/biahh/bia4.mdl" )
	player_manager.AddValidModel( "bia5", "models/jessev92/player/biahh/bia5.mdl" )
	player_manager.AddValidModel( "bia6", "models/jessev92/player/biahh/bia6.mdl" )
	player_manager.AddValidModel( "bia7", "models/jessev92/player/biahh/bia7.mdl" )
end

list.Set( "PlayerOptionsModel",  "bia1", "models/jessev92/player/biahh/bia1.mdl" )
list.Set( "PlayerOptionsModel",  "bia2", "models/jessev92/player/biahh/bia2.mdl" )
list.Set( "PlayerOptionsModel",  "bia3", "models/jessev92/player/biahh/bia3.mdl" )
list.Set( "PlayerOptionsModel",  "bia4", "models/jessev92/player/biahh/bia4.mdl" )
list.Set( "PlayerOptionsModel",  "bia5", "models/jessev92/player/biahh/bia5.mdl" )
list.Set( "PlayerOptionsModel",  "bia6", "models/jessev92/player/biahh/bia6.mdl" )
list.Set( "PlayerOptionsModel",  "bia7", "models/jessev92/player/biahh/bia7.mdl" )