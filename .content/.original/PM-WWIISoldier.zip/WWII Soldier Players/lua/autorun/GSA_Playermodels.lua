if (SERVER) then
	player_manager.AddValidModel( "GS Airborne", "models/Player/gs_airborne.mdl" )
	player_manager.AddValidModel( "GS Army", "models/Player/gs_army.mdl" )
	player_manager.AddValidModel( "GS Officer", "models/Player/gs_officer.mdl" ) 
	player_manager.AddValidModel( "GS Officer BDU", "models/Player/gs_officer_battle.mdl" ) 
	player_manager.AddValidModel( "GS Pilot", "models/Player/gs_pilot.mdl" ) 
	player_manager.AddValidModel( "GS Recruit", "models/Player/gs_recruit.mdl" )   
	player_manager.AddValidModel( "GS Special Forces", "models/Player/gs_special.mdl" )   
end

list.Set( "PlayerOptionsModel",  "GS Airborne", "models/Player/gs_airborne.mdl" )
list.Set( "PlayerOptionsModel",  "GS Army", "models/Player/gs_army.mdl" )
list.Set( "PlayerOptionsModel",  "GS Officer", "models/Player/gs_officer.mdl" )
list.Set( "PlayerOptionsModel",  "GS Officer BDU", "models/Player/gs_officer_battle.mdl" )
list.Set( "PlayerOptionsModel",  "GS Pilot", "models/Player/gs_pilot.mdl" )
list.Set( "PlayerOptionsModel",  "GS Recruit", "models/Player/gs_recruit.mdl" )
list.Set( "PlayerOptionsModel",  "GS Special Forces", "models/Player/gs_special.mdl" )